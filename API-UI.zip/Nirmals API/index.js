require('dotenv').config();
var express = require('express');
var path = require('path');
var app = express();
var routes = require('./api/routes');
var bodyParser = require('body-parser');
// const cors = require('cors');

// const corsOption = {
//     origin: ['http://localhost:3001','http://localhost:3000']
// };

const PORT = process.env.PORT?process.env.PORT:3000;
app.set('port',PORT);
app.use(express.static(path.join(__dirname,'view/build')));
app.use('/node_modules',express.static(path.join(__dirname,'node_modules')));
app.use(bodyParser.urlencoded({extened : false}));
app.use(bodyParser.json());
// app.use(cors(corsOption));
app.use('/api',routes);

var server = app.listen(app.get('port'),function() {
    console.log("Welcome to Nirmals API");
    console.log(app.get('port'));
});