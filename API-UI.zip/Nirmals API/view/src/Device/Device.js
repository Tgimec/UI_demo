import React from 'react'
import './Device.css';
import axios from 'axios';
import { Button,Modal} from 'react-bootstrap'; 

class Device extends React.Component {

  constructor(props){
    super();
    this.state = {
      formData: {
        accountNumber: null,
        aclTemplateUuid: null,
        additionalBandwidth: null,
        core: null,
        deviceManagementType: null,
        deviceTypeCode: null,
        hostNamePrefix: null,
        interfaceCount: null,
        keyName: null,
        licenseMode: null,
        metroCode: null,
        notifications: null,
        packageCode: null,
        secondaryaccountNumber: null,
        secondaryaclTemplateUuid: null,
        secondaryadditionalBandwidth: null,
        secondaryhostNamePrefix: null,
        secondarymetroCode: null,
        secondarynotifications: null,
        secondaryvirtualDeviceName: null,
        termLength: null,
        username: null,
        version: null,
        virtualDeviceName: null
      },
      showResponseModal:false,
      responseMessage: ""
    }
    this.handleSubmit=this.handleSubmit.bind(this);
    this.handleOnChange = this.handleOnChange.bind(this);
    this.config = props.config;
  }

  async handleSubmit(event){
    event.preventDefault();
    console.log(this.state);
    let formData = Object.assign({}, this.state.formData);

    //Modify state variable data structure before sending to API
    formData['notifications'] = [formData['notifications']];
    formData['userPublicKey'] = {
      "username":formData["username"],
      "keyName":formData["keyName"]

    };
    delete formData["username"];
    delete formData["keyName"];

    try{
      const deviceApiResponse = await axios.post(this.config.api_url+'/device', formData);
      this.setState({"showResponseModal":true,"responseMessage":"Device Successfully Created"})
      console.log(deviceApiResponse.data);
    }
    catch(err){
      this.setState({"showResponseModal":true,"responseMessage":"Error while creating device"})
      console.log(err);
    }

  }

  handleOnChange = (e) => {
    const { value, name } = e.target;
    let formData = this.state.formData;
    formData[name] = value;
    this.setState({ "formData" : formData });
  }

  handleModal(){
    this.setState({showResponseModal:!this.state.showResponseModal});
  }

  render(){
    return (
      <div className="col-md-12 mt-5">
          <div className="card">
              <h4 className="card-header">FORM</h4>
              <div className="card-body">
              <form>
              <div className="row">
                <div className="col-md-4">
                  <div className="form-group">
                    <label >MetroCode</label>
                    <input name = "metroCode" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div >MetroCode is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label >DeviceTypeCode</label>
                    <input name = "deviceTypeCode" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>DeviceTypeCode is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>TermLength</label>
                    <input name = "termLength" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>TermLength is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label >LicenseMode</label>
                    <input name ="licenseMode" type="text"  className="form-control" onChange={this.handleOnChange} />
                    <div className="invalid-feedback">
                      <div>LicenseMode is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>PackageCode</label>
                    <input name="packageCode" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>PackageCode is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label >VirtualDeviceName</label>
                    <input name="virtualDeviceName" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}}  className="invalid-feedback">
                      <div>VirtualDeviceName is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Notifications</label>
                    <input name="notifications" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}}className="invalid-feedback">
                      <div>Notifications is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>HostNamePrefix</label>
                    <input name="hostNamePrefix" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>HostNamePrefix is required</div>
                    </div>
                  </div>											
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label>AclTemplateUuid</label>
                    <input name="aclTemplateUuid" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>AclTemplateUuid is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>AccountNumber</label>
                    <input name = "accountNumber" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>AccountNumber is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Version</label>
                    <input name="version" type="text"className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>Version is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>InterfaceCount</label>
                    <input name="interfaceCount" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>InterfaceCount is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>DeviceManagementType</label>
                    <input name="deviceManagementType" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>DeviceManagementType is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Core</label>
                    <input name="core" type="text"className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>Core is required</div>
                    </div>
                  </div>											
                  <div className="form-group">
                    <label>Username</label>
                    <input name="username" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>Username is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>KeyName</label>
                    <input name="keyName" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>KeyName is required</div>
                    </div>
                  </div>						
                </div>
                <div className="col-md-4">
                  <div className="form-group">
                    <label>SecondaryMetroCode</label>
                    <input name="secondarymetroCode" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>SecondaryMetroCode is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>SecondaryHostNamePrefix</label>
                    <input name="secondaryhostNamePrefix" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>SecondaryHostNamePrefix is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>SecondaryNotifications</label>
                    <input name="secondarynotifications" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}}className="invalid-feedback">
                      <div>SecondaryNotifications is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>SecondaryVirtualDeviceName</label>
                    <input name="secondaryvirtualDeviceName" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>SecondaryVirtualDeviceName is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>SecondaryAdditionalBandwidth</label>
                    <input name="secondaryadditionalBandwidth" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>SecondaryAdditionalBandwidth is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>SecondaryAclTemplateUuid</label>
                    <input name="secondaryaclTemplateUuid" type="text" className="form-control" onChange={this.handleOnChange} />
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>SecondaryAclTemplateUuid is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>SecondaryAccountNumber</label>
                    <input name="secondaryaccountNumber" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>secondaryaccountNumber is required</div>
                    </div>
                  </div>
                  <div className="form-group">
                    <label>AdditionalBandwidth</label>
                    <input name="additionalBandwidth" type="text" className="form-control" onChange={this.handleOnChange}/>
                    <div style = {{display:"none"}} className="invalid-feedback">
                      <div>AdditionalBandwidth is required</div>
                    </div>
                  </div>
                </div>
              </div>
                      <button style= {{float: "right"}} className="btn btn-primary" onClick={this.handleSubmit}>
                          <span  className="spinner-border-sm mr-1"></span>
                          Save
                      </button>
                  </form>
              </div>
          </div>
          <Modal show={this.state.showResponseModal} onHide={()=>this.handleModal()}>  
          <Modal.Header closeButton>Status</Modal.Header>  
          <Modal.Body>{this.state.responseMessage}</Modal.Body>  
          <Modal.Footer>  
            <Button onClick={()=>this.handleModal()}>Close</Button>  
            {/* <Button onClick={()=>this.handleModal()}>Save</Button>   */}
          </Modal.Footer>  
        </Modal>  
      </div>
    );
  }
  
}

export default Device;
