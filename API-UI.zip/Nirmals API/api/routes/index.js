
var express = require('express');
var router = express.Router();
var ctrlDevice = require('../controllers/device.controller');

router
    .route('/device')
    .post(ctrlDevice.createDevice);

module.exports = router