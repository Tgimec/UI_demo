const axios = require('axios').default;

module.exports.createDevice = function(req,res){
    const data = req.body;
    console.log(data);

    const headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+process.env.DEVICE_API_TOKEN
    };

    axios.post("https://api.equinix.com/ne/v1/devices?draft=true", data, {
        headers: headers
      })
      .then((response) => {
        console.log(response.data);
        res.status(200).json(response.data);
      })
      .catch((error) => {
        res.status(400).json(error);
      })

   
};

